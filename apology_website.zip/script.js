function showHeart() {
    document.getElementById("heart").style.display = "block";
}
